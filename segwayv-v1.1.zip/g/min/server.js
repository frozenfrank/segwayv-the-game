/* Segwayv the game source code  --- server.js
    Written by: James Finlinson 2016
    Please play, but dont abuse the system or try to hack it
    ENJOY! :)
*/
var whitelistRef,gameServer,variables,pingsRef,Firebase,serverHelper={resizeCanvas:function(a){gameServer.child("gameVariables/canvasSize").set(function(){if(a.auto)return[window.innerWidth-2,window.innerHeight-2];if(a.target){var b=document.getElementById(a.target);return[parseInt(b.querySelector("#width").value,10),parseInt(b.querySelector("#height").value,10)]}return[a.width,a.height]}())}};
function init(){variables.activeUser="server";messageRef.on("child_added",function(a){var b=a.val();if("server"===b.target)switch(b.action){case "join":whitelistRef.child(b.origin).set(!0);variables.debugFlags.showStagesPerformed&&console.log("added "+b.origin+" to the game");break;case "status":switch(b.subAction){case "ping":pingsRef.child(b.origin).set(b.localeTimestamp)}}b.target===variables.activeUser&&a.ref.remove()});cleanUsers()}
function cleanUsers(a){console.log("cleaning users");pingsRef.child(variables.activeUser).set(firebase.database.ServerValue.TIMESTAMP).then(function(a){pingsRef.once("value").then(function(a){a=a.val();for(var b in a)a.hasOwnProperty(b)&&a!==variables.activeUser&&a.server-a[b]>variables.pingAllowance+variables.pingFrequency&&removeUser(b)})});a||setTimeout(cleanUsers,variables.cleanUsersFrequency)}
function removeUser(a){console.log("Removing",a);whitelistRef.child(a).remove();objectsRef.child(a).remove();pingsRef.child(a).remove();console.log("removed:",a)};