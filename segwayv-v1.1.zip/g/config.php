<?php
    $DEVserver = true;
    $minifiedCode = false;
    $noLoadPattern = '/(\/NOLOAD|game\.js)/';
        //the NOLOAD files as well as game.js we will include it later...
?>